MK Studio Pune website
======================

Files
  index.html              the whole website (HTML, CSS and JavaScript in one file)
  download_thumbnails.py  optional: saves all film thumbnails into the images/ folder
  images/                 thumbnails go here after you run the script

Run it on your computer
  Option 1: double-click index.html. It opens in your browser.
  Option 2 (recommended): open a terminal in this folder and run
      python -m http.server 8000
  then visit http://localhost:8000
  (or in VS Code, right-click index.html > "Open with Live Server")

Needs internet
  The 3D camera loads three.js and the fonts load from Google Fonts.
  Film thumbnails load from mkproduction.org and YouTube until you save them locally.
  Use Chrome, Edge, Firefox or Safari with WebGL enabled.

Save the thumbnails locally (optional)
  With internet on, run:  python download_thumbnails.py
  It downloads every thumbnail into images/ and updates index.html to use them.
  Your original page is kept as index.original.html.

Edit your content
  All text is in index.html. Search for the section you want (hero, about, services, films, rentals, contact).

Add your photos
  The four service frames are placeholders. Put your photos in the images folder, then set data-src, for example:
      <div class="frame" data-src="images/studio.jpg">

Put it online
  Upload this folder to Netlify, Vercel or GitHub Pages. No build step is needed.
