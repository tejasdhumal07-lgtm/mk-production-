"""Save every film thumbnail into the images/ folder and point index.html at the local copies.

Run once, with internet:   python download_thumbnails.py
Needs only Python 3. A backup of the original page is saved as index.original.html.
"""
import os, re, shutil, sys, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
PAGE = os.path.join(HERE, "index.html")
IMG_DIR = os.path.join(HERE, "images")


def local_name(url):
    m = re.search(r"/vi/([^/]+)/", url)
    if m:
        return "yt_%s.jpg" % m.group(1)
    return os.path.basename(url.split("?")[0])


def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.read()


def main():
    html = open(PAGE, encoding="utf-8").read()
    urls = sorted(set(re.findall(r'<img src="(https://[^"]+)"', html)))
    if not urls:
        print("No remote thumbnails found. Nothing to do.")
        return
    os.makedirs(IMG_DIR, exist_ok=True)
    backup = os.path.join(HERE, "index.original.html")
    if not os.path.exists(backup):
        shutil.copyfile(PAGE, backup)
    ok = failed = 0
    for url in urls:
        name = local_name(url)
        try:
            data = fetch(url)
            if len(data) < 500:
                raise ValueError("file too small")
            with open(os.path.join(IMG_DIR, name), "wb") as f:
                f.write(data)
            html = html.replace('src="%s"' % url, 'src="images/%s"' % name)
            ok += 1
            print("saved  ", name)
        except Exception as e:
            failed += 1
            print("failed ", url, "-", e)
    html = html.replace(' referrerpolicy="no-referrer"', "")
    open(PAGE, "w", encoding="utf-8").write(html)
    print("\nDone: %d saved, %d failed. Failed ones still load from the internet." % (ok, failed))


if __name__ == "__main__":
    sys.exit(main())
